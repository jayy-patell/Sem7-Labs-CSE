import UIKit

struct Book {
    var name: String
    var author: String
    var price: Int
    var bookssold: Int
}

struct Student {
    var book1: Book
    var book2: Book
}
var book1=Book(name:"HP",author:"george",price:120,bookssold:10)
var book2=Book(name:"PJ",author:"georgie",price:12,bookssold:1)
var book3=Book(name:"HP1",author:"george1",price:120,bookssold:10)
var book4=Book(name:"PJ1",author:"georgie1",price:12,bookssold:1)
var stud = Student(book1: book1, book2: book2)
var stud1 = Student(book1: book3, book2: book4)

print(stud1.book1,"\r",stud1.book2)



